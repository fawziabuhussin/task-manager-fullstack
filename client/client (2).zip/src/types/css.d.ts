declare module '*.module.css' {
  const classes: { [key: string]: string };
  export default classes;
}

// אל תכריז על '*.css' כללי כדי לא להתנגש עם vite/client.d.ts
