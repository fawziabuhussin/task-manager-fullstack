﻿// client/src/lib/http.ts
import axios from "axios";

function normalize(u?: string) {
  return (u ?? "").replace(/\/+$/, "");
}

const base =
  normalize(import.meta.env.VITE_API_URL) ||
  "http://localhost:3000/api";

const http = axios.create({
  baseURL: base,
  withCredentials: true, // נשמר cookie מהשרת
  headers: { "Content-Type": "application/json" },
});

export default http;
