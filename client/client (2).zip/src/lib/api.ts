﻿import axios, { AxiosHeaders } from 'axios';

const BASE = (import.meta.env.VITE_API_URL as string) || 'http://localhost:3000/api';

export const api = axios.create({
  baseURL: BASE,          // הבסיס כולל /api
  withCredentials: true,  // נדרש ל-HttpOnly cookies
});

// הוספת x-csrf-token אוטומטית בבקשות משנות מצב (POST/PUT/PATCH/DELETE)
api.interceptors.request.use(async (config) => {
  const method = (config.method || '').toLowerCase();
  if (['post', 'put', 'patch', 'delete'].includes(method)) {
    const ensureHeader = (name: string, value: string) => {
      if (config.headers instanceof AxiosHeaders) {
        config.headers.set(name, value);
      } else if (config.headers) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (config.headers as any)[name] = value;
      } else {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        config.headers = { [name]: value } as any;
      }
    };

    const tokenFromCookie = getCookie('csrfToken');
    if (tokenFromCookie) {
      ensureHeader('x-csrf-token', tokenFromCookie);
    } else {
      // משיגים CSRF חדש במידת הצורך
      const origin = BASE.replace(/\/api$/, '');
      const resp = await fetch(`${origin}/api/auth/csrf`, { credentials: 'include' });
      const data: { csrfToken?: string } = await resp.json().catch(() => ({}));
      const token = data.csrfToken || getCookie('csrfToken') || '';
      ensureHeader('x-csrf-token', token);
    }
  }
  return config;
});

function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
  return match ? decodeURIComponent(match[2]) : null;
}

export type User = { id: string; email: string };

// עטיפת auth מסודרת (שימוש בה ב-AuthContext)
export const auth = {
  me: () => api.get('/auth/me').then(r => r.data),
  signup: (email: string, password: string) => api.post('/auth/signup', { email, password }).then(r => r.data),
  verify: (email: string, code: string) => api.post('/auth/verify', { email, code }).then(r => r.data),
  login: (email: string, password: string) => api.post('/auth/login', { email, password }).then(r => r.data),
  logout: () => api.post('/auth/logout').then(r => r.data),
};

// קישורי DEV
export const devLinks = {
  mailbox: () => BASE.replace(/\/api$/, '') + '/dev/mailbox',
};
